﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProudChickenEksamen.Model
{
    class EMail
    {
        public string ID { get; set; }
        public string Dato { get; set; }
        public string EmailStandardBesked { get; set; }
        public string Custom { get; set; }
    }
}
