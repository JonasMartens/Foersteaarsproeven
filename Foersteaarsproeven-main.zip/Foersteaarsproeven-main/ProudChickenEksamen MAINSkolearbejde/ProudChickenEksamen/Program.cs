﻿using ProudChickenEksamen.Controller;

Console.WriteLine();
Controller controller = new Controller();
controller.Run();